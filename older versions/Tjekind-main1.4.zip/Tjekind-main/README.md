# Tjekind

Vores egen producerede tjek ind system. Er skrevet i php og driver til at læse kortene er skrevet i python

## Driver
Systemet har driver til NFC læseren til både Windows og Linux. Driverne er testen og fungerer på Windows 10 og Raspberry Pi linux, Raspbarian

## Frontend
## Backend
Installeret eks. Apache server som er i stand til at køre php-filer. 

## Database
Til database er der brugt MySQL. Den kører stadig i sin gamle version: 0.00.

# Hardware krav
Der er krav til at bruge, det eneste som driveren understøtter nu.




