* 02-12-2022 KRS Installerede Apache2
* 02-12-2022 KRS Installerede PHP7.4 på Apache2
* 02-12-2022 KRS Kopierede oprindeligee kode til /var/www/tjekind mappe
* 02-12-2022 KRS Installerede MariaDB Databaseklientversion: libmysql - mysqlnd 7.4.33
* 02-12-2022 KRS Installerede phpMyAdmin Versionsinformation: 5.0.4deb2+deb11u1
* 02-12-2022 KRS Importerede oprindelige Tjekind data
* 02-12-2022 KRS Rettede tegnsæt fejl. Kører nu uden fejlbeskeder
* 05-12-2022 KRS Oprettede bruger på tjekind tabeller med det gamle password
* 05-12-2022 KRS Install Universal FireWall UFW
* 05-12-2022 KRS UFW rules: HTTP. HTTPS, VNC, shh
* 07-12-2022 KRS Made conf and launcher script
* 07-12-2022 KRS Made log function shell script (and other)
* 09-12-2022 KRS Fresh installed machine
* 12-12-2022 KRS Made correction to Python script. Problem with / vs - in input
* 13-12-2022 KRS Finalized machine. Good to go
* 13-12-2022 KRS Made IMG of new Tjekind system