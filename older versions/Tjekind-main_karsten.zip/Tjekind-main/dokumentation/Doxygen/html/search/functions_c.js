var searchData=
[
  ['search_165',['search',['../class_database.html#a19c98d3fe0b8ef7b41ae7433e75c49b3',1,'Database']]],
  ['setsortdirection_166',['setSortdirection',['../class_user.html#ad221cd3150eaa7d7bc3505ebae32700d',1,'User']]],
  ['setsorting_167',['setSorting',['../class_user.html#acaa0db80b88d59723d45528a7e57cf1e',1,'User']]]
];
