var searchData=
[
  ['search_81',['search',['../class_database.html#a19c98d3fe0b8ef7b41ae7433e75c49b3',1,'Database']]],
  ['session_82',['Session',['../class_session.html',1,'']]],
  ['session_2ephp_83',['Session.php',['../_session_8php.html',1,'']]],
  ['setsortdirection_84',['setSortdirection',['../class_user.html#ad221cd3150eaa7d7bc3505ebae32700d',1,'User']]],
  ['setsorting_85',['setSorting',['../class_user.html#acaa0db80b88d59723d45528a7e57cf1e',1,'User']]],
  ['sletelev_2ephp_86',['sletElev.php',['../slet_elev_8php.html',1,'']]],
  ['som_87',['som',['../dashboard_8php.html#a222c841e2f3589bbbe1f801560838c9e',1,'dashboard.php']]]
];
