var searchData=
[
  ['copy_186',['copy',['../rediger_elev_8php.html#a57d891e40cb5823359099ef6851a5032',1,'redigerElev.php']]]
];
