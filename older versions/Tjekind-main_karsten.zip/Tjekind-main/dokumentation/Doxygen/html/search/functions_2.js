var searchData=
[
  ['begin_5ftransaction_129',['begin_transaction',['../class_database.html#ab8e0d5980a9cf1ad251d45be20fe6c28',1,'Database']]]
];
