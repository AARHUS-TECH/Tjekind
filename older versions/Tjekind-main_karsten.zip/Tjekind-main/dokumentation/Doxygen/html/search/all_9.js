var searchData=
[
  ['if_59',['if',['../opret_elev_8php.html#adc2cf6c9b5039248f754802ea729932b',1,'if():&#160;opretElev.php'],['../opret_instruktoer_8php.html#a287c50c43aaced07fdc377c7d76d037c',1,'if():&#160;opretInstruktoer.php'],['../rediger_instruktoer_8php.html#a287c50c43aaced07fdc377c7d76d037c',1,'if():&#160;redigerInstruktoer.php'],['../elev_2index_8php.html#a046c45c7274aed35b785a89a4edd03b3',1,'if():&#160;index.php']]],
  ['index_2ephp_60',['index.php',['../admin_2index_8php.html',1,'(Global Namespace)'],['../elev_2index_8php.html',1,'(Global Namespace)'],['../index_8php.html',1,'(Global Namespace)']]],
  ['index2_2ephp_61',['index2.php',['../index2_8php.html',1,'']]],
  ['init_2ephp_62',['init.php',['../init_8php.html',1,'']]],
  ['input_63',['Input',['../class_input.html',1,'']]],
  ['input_2ephp_64',['Input.php',['../_input_8php.html',1,'']]],
  ['insert_65',['insert',['../class_database.html#aa589eba93d965df6a3466315f79cc2b3',1,'Database']]],
  ['instruktoercontrols_66',['instruktoerControls',['../class_user.html#af33392c3d99689cb2ed434293887ced7',1,'User']]],
  ['isadmin_67',['isAdmin',['../class_user.html#a0eaad37005bf0ae277e74f2ea2c58b91',1,'User']]],
  ['istjekindallowed_68',['isTjekIndAllowed',['../class_user.html#a8017a4d1cc44e9a35f00ffb44e55011b',1,'User']]],
  ['istjekudallowed_69',['isTjekUdAllowed',['../class_user.html#aac0e29ee3bc3db4499811827233df0dc',1,'User']]]
];
