var searchData=
[
  ['foreach_189',['foreach',['../dashboard_8php.html#a5d3fc5f9a5c34c5f0435f38a8d168185',1,'foreach():&#160;dashboard.php'],['../index2_8php.html#a5d3fc5f9a5c34c5f0435f38a8d168185',1,'foreach():&#160;index2.php']]]
];
