var searchData=
[
  ['get_146',['get',['../class_config.html#a1772950043190c6378a10f263702c58c',1,'Config\get()'],['../class_input.html#a6086bc3dcd50f684c84752625ee26d25',1,'Input\get()'],['../class_session.html#a3ab93001efaf4399c6b2a576c0901454',1,'Session\get()']]],
  ['get_5flast_5fid_147',['get_last_id',['../class_database.html#a5e67e1080df19c59662b0f92dc8d9184',1,'Database']]],
  ['getallelever_148',['getAllElever',['../class_user.html#a11e6b51add425d8c0c6df0a2f7bd8412',1,'User']]],
  ['getallinstruktoerer_149',['getAllInstruktoerer',['../class_user.html#a58d9a30b3f788a38476eec62807c88ff',1,'User']]],
  ['getallnotactiveelever_150',['getAllNotActiveElever',['../class_user.html#abf2b957c037fd80ad0dfcf3b94622a99',1,'User']]],
  ['geterrormessage_151',['getErrorMessage',['../class_errors.html#af8c3bef7b4a882db0b3f07c0888ae7e1',1,'Errors']]],
  ['getinfo_152',['getInfo',['../class_user.html#a2d200d5eb501b34219ad51e700ce6cb6',1,'User']]],
  ['getstatusclass_153',['getStatusClass',['../class_user.html#a48a3cd7fe6de9dcc51c0e2d0c1c101bc',1,'User']]],
  ['getstatusstring_154',['getStatusString',['../class_user.html#a3f2ffe5f65bc19998ec282ab0232d027',1,'User']]],
  ['getsuccessmessage_155',['getSuccessMessage',['../class_errors.html#aef3548792900c0cbc649f7e89da0f78d',1,'Errors']]]
];
