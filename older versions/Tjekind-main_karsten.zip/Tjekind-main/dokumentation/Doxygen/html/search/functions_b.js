var searchData=
[
  ['rollback_164',['rollback',['../class_database.html#a914d5ca2edfdcaf88570403cf482f9f4',1,'Database']]]
];
