var searchData=
[
  ['_5f_5fconstruct_125',['__construct',['../class_database.html#a2852f635197e76a838486e64e00aac9f',1,'Database\__construct()'],['../class_user.html#ab85808b180763aae0ad612ddac38f630',1,'User\__construct()']]],
  ['_5f_5fdestruct_126',['__destruct',['../class_database.html#a00c6bc5be06a02811dd6ce2172eefcfc',1,'Database']]]
];
