var searchData=
[
  ['if_190',['if',['../opret_elev_8php.html#adc2cf6c9b5039248f754802ea729932b',1,'if():&#160;opretElev.php'],['../opret_instruktoer_8php.html#a287c50c43aaced07fdc377c7d76d037c',1,'if():&#160;opretInstruktoer.php'],['../rediger_instruktoer_8php.html#a287c50c43aaced07fdc377c7d76d037c',1,'if():&#160;redigerInstruktoer.php'],['../elev_2index_8php.html#a046c45c7274aed35b785a89a4edd03b3',1,'if():&#160;index.php']]]
];
