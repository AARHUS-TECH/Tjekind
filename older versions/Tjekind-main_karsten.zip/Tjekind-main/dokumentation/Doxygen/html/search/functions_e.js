var searchData=
[
  ['update_172',['update',['../class_database.html#a306decc8e9acabbea4c8c24f31565f1a',1,'Database\update()'],['../class_user.html#a9b80c8b6b1e7ed1be96b713261742319',1,'User\update()']]]
];
