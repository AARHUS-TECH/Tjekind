var searchData=
[
  ['redigerelev_2ephp_76',['redigerElev.php',['../rediger_elev_8php.html',1,'']]],
  ['redigerinstruktoer_2ephp_77',['redigerInstruktoer.php',['../rediger_instruktoer_8php.html',1,'']]],
  ['redirect_78',['Redirect',['../class_redirect.html',1,'']]],
  ['redirect_2ephp_79',['Redirect.php',['../_redirect_8php.html',1,'']]],
  ['rollback_80',['rollback',['../class_database.html#a914d5ca2edfdcaf88570403cf482f9f4',1,'Database']]]
];
