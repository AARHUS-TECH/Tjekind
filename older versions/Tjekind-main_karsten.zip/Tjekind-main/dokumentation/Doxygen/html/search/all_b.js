var searchData=
[
  ['opretelev_71',['opretElev',['../class_user.html#a2faa7889ef780856c6b86ee8874ab568',1,'User']]],
  ['opretelev_2ephp_72',['opretElev.php',['../opret_elev_8php.html',1,'']]],
  ['opretinstruktoer_73',['opretInstruktoer',['../class_user.html#a6a453dacb45ce65c51b4cf36f59ef233',1,'User']]],
  ['opretinstruktoer_2ephp_74',['opretInstruktoer.php',['../opret_instruktoer_8php.html',1,'']]]
];
