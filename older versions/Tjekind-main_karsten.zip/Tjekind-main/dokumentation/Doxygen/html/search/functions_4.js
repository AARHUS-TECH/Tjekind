var searchData=
[
  ['delete_136',['delete',['../class_database.html#ae65ceadb634ad306ba8884a9b799e669',1,'Database\delete()'],['../class_session.html#a65494672eb7440e6d1ae78e9b43f2e07',1,'Session\delete()'],['../class_user.html#a7ff026c54b0c6dab7ac29264c65907b2',1,'User\delete()']]]
];
