var searchData=
[
  ['insert_156',['insert',['../class_database.html#aa589eba93d965df6a3466315f79cc2b3',1,'Database']]],
  ['instruktoercontrols_157',['instruktoerControls',['../class_user.html#af33392c3d99689cb2ed434293887ced7',1,'User']]],
  ['isadmin_158',['isAdmin',['../class_user.html#a0eaad37005bf0ae277e74f2ea2c58b91',1,'User']]],
  ['istjekindallowed_159',['isTjekIndAllowed',['../class_user.html#a8017a4d1cc44e9a35f00ffb44e55011b',1,'User']]],
  ['istjekudallowed_160',['isTjekUdAllowed',['../class_user.html#aac0e29ee3bc3db4499811827233df0dc',1,'User']]]
];
