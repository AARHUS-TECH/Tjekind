var searchData=
[
  ['opretelev_161',['opretElev',['../class_user.html#a2faa7889ef780856c6b86ee8874ab568',1,'User']]],
  ['opretinstruktoer_162',['opretInstruktoer',['../class_user.html#a6a453dacb45ce65c51b4cf36f59ef233',1,'User']]]
];
